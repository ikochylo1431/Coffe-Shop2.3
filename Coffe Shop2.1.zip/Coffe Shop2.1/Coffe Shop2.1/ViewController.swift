//
//  ViewController.swift
//  Coffe Shop2.1
//
//  Created by Illya Kochylo on 12/3/18.
//  Copyright © 2018 Illya Kochylo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

